#!/bin/bash

cd ~/"$TR_TORRENT_DIR"
mv "$TR_TORRENT_NAME" ~/Videos


